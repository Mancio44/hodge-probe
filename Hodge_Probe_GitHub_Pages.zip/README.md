# Hodge Proof Probe

GitHub Pages-ready static site.

## Pubblicazione
1. Crea un repository pubblico su GitHub.
2. Carica `index.html` nella root del repository.
3. Vai in Settings → Pages.
4. In "Build and deployment" scegli "Deploy from a branch".
5. Seleziona il branch principale e la cartella `/ (root)`.
6. Salva. Dopo la pubblicazione GitHub fornirà il link del sito.

Il sito è completamente client-side: non richiede un server.
